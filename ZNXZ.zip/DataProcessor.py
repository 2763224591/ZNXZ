import os
import hashlib
from abc import ABC, abstractmethod
# 文档加载器
from langchain_community.document_loaders import (
    PyPDFLoader, TextLoader, UnstructuredWordDocumentLoader
)
from typing import List, Dict, Any, Optional, Tuple
from langchain_community.document_loaders import UnstructuredXMLLoader
from langchain_community.document_loaders import JSONLoader

# ================================
# 3. 数据处理抽象基类
# ================================
class DataProcessor(ABC):
    """数据处理器抽象基类，支持扩展"""

    @abstractmethod
    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理该文件类型"""
        pass

    @abstractmethod
    def load_documents(self, file_path: str) -> List[Any]:
        """加载文档"""
        pass

    @abstractmethod
    def get_file_hash(self, file_path: str) -> str:
        """获取文件哈希值用于增量更新"""
        pass
# ================================
# 4. 数据处理工厂类
# ================================
class DataProcessorFactory:
    """数据处理器工厂类"""

    def __init__(self):
        self.processors = [
            PDFProcessor(),
            TextProcessor(),
            WordProcessor(),
            XMLProcessor(),
            JSONProcessor()
        ]

    def get_processor(self, file_path: str) -> Optional[DataProcessor]:
        """根据文件类型获取对应的处理器"""
        for processor in self.processors:
            if processor.can_process(file_path):
                return processor
        return None
# ================================
# 5. 具体数据处理器实现
# ================================
class PDFProcessor(DataProcessor):
    """PDF文档处理器"""

    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理PDF文件"""
        if file_path.lower().endswith('.pdf'):
            print(f"检测到PDF文件: {os.path.basename(file_path)}")
            return True
        else:
            return False

    def load_documents(self, file_path: str) -> List[Any]:
        """加载并解析PDF文档内容"""
        print(f"开始处理PDF文档: {os.path.basename(file_path)}")
        try:
            loader = PyPDFLoader(file_path)
            documents = loader.load()
            return documents
        except Exception as e:
            print(f"处理失败")
            raise

    def get_file_hash(self, file_path: str) -> str:
        print(f"开始计算PDF文档hash: {os.path.basename(file_path)}")
        with open(file_path, 'rb') as f:
            return hashlib.md5(f.read()).hexdigest()

class TextProcessor(DataProcessor):
    """文本文档处理器"""
    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理文本文件"""
        if file_path.lower().endswith(('.txt', '.md')):
            print(f"检测到文本文件: {os.path.basename(file_path)}")
            return True
        else:
            return False

    def load_documents(self, file_path: str) -> List[Any]:
        print(f"开始处理文本文档: {os.path.basename(file_path)}")
        loader = TextLoader(file_path, encoding='utf-8')
        return loader.load()

    def get_file_hash(self, file_path: str) -> str:
        print(f"开始计算文本文档hash: {os.path.basename(file_path)}")
        with open(file_path, 'r', encoding='utf-8') as f:
            return hashlib.md5(f.read().encode()).hexdigest()


class WordProcessor(DataProcessor):
    """Word文档处理器"""
    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理docx文件"""
        if file_path.lower().endswith('.docx'):
            print(f"检测到docx文件: {os.path.basename(file_path)}")
            return True
        else:
            return False

    def load_documents(self, file_path: str) -> List[Any]:
        print(f"开始处理docx文档: {os.path.basename(file_path)}")
        try:
            loader = UnstructuredWordDocumentLoader(file_path)
            return loader.load()

        except ImportError as e:
            # 检查错误信息中是否包含docx
            if "docx" in str(e).lower():
                print("缺少处理Word文档所需的依赖库: python-docx")
                print("""请通过以下命令安装: pip install python-docx"
                        python命令行
                        >>> import nltk
                        >>> nltk.download('punkt')
                        >>> nltk.download('averaged_perceptron_tagger')
                      """)
            else:
                print(f"导入失败: {e}")
            raise

    def get_file_hash(self, file_path: str) -> str:
        with open(file_path, 'rb') as f:
            print(f"开始计算docx文档hash: {os.path.basename(file_path)}")
            return hashlib.md5(f.read()).hexdigest()

class XMLProcessor(DataProcessor):
    """XML文档处理器"""

    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理XML文件"""
        if file_path.lower().endswith('.xml'):
            print(f"检测到XML文件: {os.path.basename(file_path)}")
            return True
        else:
            return False

    def load_documents(self, file_path: str) -> List[Any]:
        print(f"开始处理XML文档: {os.path.basename(file_path)}")
        try:
            # 加载XML文档
            loader = UnstructuredXMLLoader(file_path)
            return loader.load()
        except Exception as e:
            print(f"处理XML文档失败: {e}")
            raise

    def get_file_hash(self, file_path: str) -> str:
        print(f"开始计算XML文档hash: {os.path.basename(file_path)}")
        with open(file_path, 'rb') as f:
            return hashlib.md5(f.read()).hexdigest()

class JSONProcessor(DataProcessor):
    """JSON文档处理器"""

    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理JSON文件"""
        if file_path.lower().endswith('.json'):
            print(f"检测到JSON文件: {os.path.basename(file_path)}")
            return True
        else:
            return False

    def load_documents(self, file_path: str) -> List[Any]:
        print(f"开始处理JSON文档: {os.path.basename(file_path)}")
        try:
            # 配置JSON加载器
            loader = JSONLoader(
                file_path=file_path,
                jq_schema='.[]',  # 假设JSON是对象数组
                text_content=False,  # 处理整个文档内容
                metadata_func=self._extract_metadata
            )
            return loader.load()

        except Exception as e:
            print(f"处理JSON文档失败: {e}")

    def _extract_metadata(self, record: dict, metadata: dict) -> dict:
        """从JSON记录中提取元数据"""
        # 自动提取所有字段作为元数据
        for key, value in record.items():
            # 跳过大型文本字段
            if isinstance(value, str) and len(value) > 100:
                continue
            metadata[key] = value
        return metadata

    def get_file_hash(self, file_path: str) -> str:
        print(f"开始计算JSON文档hash: {os.path.basename(file_path)}")
        with open(file_path, 'rb') as f:
            return hashlib.md5(f.read()).hexdigest()