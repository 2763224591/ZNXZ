# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

from typing import List, Dict, Any, Optional, Tuple

# 大模型接入
from llm_api import LlmApi
# 数据库类
from DatabaseManager import DatabaseManager
# 配置接入
from SystemConfig import SystemConfig
# 知识库接入
from KnowledgeBaseManager import KnowledgeBaseManager

from QueryProcessor import QueryProcessor

# ================================
# 9. 主系统类
# ================================
class SoftwareEngineeringAssistant:
    """软件工程课程小助手主系统"""

    def __init__(self,llm,neo4j_settings: dict = None):
        # 创建配置管理器并注入Neo4j设置
        self.config = SystemConfig(neo4j_settings)
        self.db_manager = DatabaseManager(self.config)
        self.kb_manager = KnowledgeBaseManager(self.config, self.db_manager, llm)
        self.query_processor = QueryProcessor(self.db_manager, llm)

        print(f"软件工程课程小助手初始化完成")

    def update_knowledge_base(self, paths: List[str]) -> Dict[str, bool]:
        """更新知识库接口"""
        print("开始更新知识库...")
        results = self.kb_manager.sync_knowledge_base(paths)
        return results

    def ask(self, question: str, chat_history: Optional[List[Tuple[str, str]]] = None) -> str:
        """提问接口"""
        return self.query_processor.query(question, chat_history)

    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        try:
            # 检查数据库连接
            result = self.db_manager.graph.query("RETURN 1 as test")
            db_status = "正常" if result else "异常"

            # 统计文档数量
            doc_count = self.db_manager.graph.query("MATCH (d:Document) RETURN count(d) as count")[0]['count']

            # 统计实体数量
            entity_count = self.db_manager.graph.query("MATCH (e:__Entity__) RETURN count(e) as count")[0]['count']

            # 统计文件记录数量
            file_count = self.db_manager.graph.query("MATCH (f:FileRecord) RETURN count(f) as count")[0]['count']

            return {
                "database_status": db_status,
                "document_count": doc_count,
                "entity_count": entity_count,
                "file_count": file_count,
                "course": "软件工程"
            }
        except Exception as e:
            return {
                "database_status": f"错误: {e}",
                "document_count": 0,
                "entity_count": 0,
                "file_count": 0,
                "course": "软件工程"
            }
import os
import hashlib
import re
from abc import ABC, abstractmethod
# 文档加载器
from langchain_community.document_loaders import (
    PyPDFLoader, TextLoader, UnstructuredWordDocumentLoader
)
from typing import List, Any, Optional
import xml.etree.ElementTree as ET
from langchain.docstore.document import Document
import json
import mammoth
from docx import Document as DocxDocument
class WordProcessor:
    """Word文档处理器"""
    def can_process(self, file_path: str) -> bool:
        """判断是否可以处理docx文件"""
        if file_path.lower().endswith('.docx'):
            print(f"检测到docx文件: {os.path.basename(file_path)}")
            return True
        else:
            return False

    def load_documents(self, file_path: str) -> List[Document]:
        """加载并解析Word文档内容，根据标题划分章节"""
        print(f"开始处理Word文档: {os.path.basename(file_path)}")

        try:
            # 验证文件路径
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"文件不存在: {file_path}")

            if not os.path.isfile(file_path):
                raise ValueError(f"路径不是文件: {file_path}")

            # 检查文件大小
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                raise ValueError(f"文件为空: {file_path}")

            print(f"文件大小: {file_size} bytes")

            # 方法1：使用python-docx读取Word文档
            content = self._extract_content_with_docx(file_path)

            # 如果docx方法失败，尝试使用mammoth
            if not content.strip():
                print("docx方法未获取到内容，尝试使用mammoth...")
                content = self._extract_content_with_mammoth(file_path)

            if not content.strip():
                raise ValueError("无法从文档中提取任何内容")

            print(f"成功提取内容，长度: {len(content)} 字符")

            # 根据标题模式划分章节
            sections = self._split_by_headers(content, file_path)

            print(f"成功提取 {len(sections)} 个章节")
            return sections

        except Exception as e:
            print(f"处理失败：{e}")
            raise

    def _extract_content_with_docx(self, file_path: str) -> str:
        """使用python-docx提取Word文档内容"""
        try:
            # 检查文件是否存在
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"文件不存在: {file_path}")

            # 检查文件扩展名
            if not file_path.lower().endswith(('.docx', '.doc')):
                raise ValueError(f"不支持的文件格式: {file_path}")

            doc = DocxDocument(file_path)
            content_lines = []

            for paragraph in doc.paragraphs:
                text = paragraph.text.strip()
                if text:
                    print(text)
                    content_lines.append(text)

            return "\n".join(content_lines)
        except Exception as e:
            print(f"使用docx提取失败: {e}")
            return ""

    def _extract_content_with_mammoth(self, file_path: str) -> str:
        """使用mammoth提取Word文档内容"""
        try:
            # 检查文件是否存在
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"文件不存在: {file_path}")

            with open(file_path, "rb") as docx_file:
                result = mammoth.extract_raw_text(docx_file)
                return result.value
        except Exception as e:
            print(f"使用mammoth提取失败: {e}")
            return ""

    def _split_by_headers(self, content: str, file_path: str = None) -> List[Document]:
        """根据标题模式划分文档内容"""
        sections = []

        # 定义多种标题模式
        header_patterns = [
            re.compile(r"^\s*#{1,6}\s+.*$", re.MULTILINE),  # Markdown标题 (# ## ### 等)
            re.compile(r"^\s*\d+(\.\d+)*\s+[^\s].*$", re.MULTILINE),  # 数字标题 (1. 1.1 等)
            re.compile(r"^\s*[第一二三四五六七八九十]\w*[章节部分]\s+.*$", re.MULTILINE),  # 中文章节
            re.compile(r"^\s*[A-Z][A-Z\s]*[：:]\s*.*$", re.MULTILINE),  # 大写字母标题
            re.compile(r"^\s*作业\d+.*$", re.MULTILINE),  # 作业标题
        ]

        lines = content.splitlines()
        current_title = None
        current_content = []

        for line in lines:
            line_stripped = line.strip()
            if not line_stripped:
                if current_title:
                    current_content.append(line)
                continue

            # 检查是否匹配任何标题模式
            is_header = False
            for pattern in header_patterns:
                if pattern.match(line_stripped):
                    is_header = True
                    break

            if is_header:
                # 发现新标题，保存之前的章节
                if current_title and current_content:
                    page_content = "\n".join(current_content).strip()
                    if page_content:  # 只有内容不为空时才创建Document
                        metadata = {
                            "title": current_title.strip(),
                            "source": os.path.basename(file_path) if file_path else "word_document",
                            "file_path": file_path
                        }
                        sections.append(Document(page_content=page_content, metadata=metadata))

                # 开始新章节
                current_title = line_stripped
                current_content = []
            else:
                # 非标题行，添加到当前章节内容
                if current_title:
                    current_content.append(line)

        # 处理最后一个章节
        if current_title and current_content:
            page_content = "\n".join(current_content).strip()
            if page_content:
                metadata = {
                    "title": current_title.strip(),
                    "source": os.path.basename(file_path) if file_path else "word_document",
                    "file_path": file_path
                }
                sections.append(Document(page_content=page_content, metadata=metadata))

        # 如果没有找到任何标题，将整个文档作为一个章节
        if not sections and content.strip():
            metadata = {
                "title": "整个文档",
                "source": os.path.basename(file_path) if file_path else "word_document",
                "file_path": file_path
            }
            sections.append(Document(page_content=content.strip(), metadata=metadata))

        return sections

    def get_file_hash(self, file_path: str) -> str:
        with open(file_path, 'rb') as f:
            print(f"开始计算docx文档hash: {os.path.basename(file_path)}")
            return hashlib.md5(f.read()).hexdigest()

    @property
    def custom_chunking(self) -> bool:
        """已实现自定义分块"""
        return True
# ================================
# 使用示例
# ================================
# Press the green button in the gutter to run the script.
if __name__ == "__main__":
    # 全局大模型实例
    llm_api = LlmApi()
    print("=== 使用统一的LlmApi API ===")
    # 定义Neo4j配置字典
    Neo4jSetting = {
        "url": "bolt://localhost:7687",
        "username": "neo4j",
        "password": "12345678"
    }
    # 初始化时传入配置
    assistant = SoftwareEngineeringAssistant(llm_api,Neo4jSetting)

    # 检查系统状态
    status = assistant.get_system_status()
    print("系统状态:", status)

    # 更新知识库 注意设定目录
    results = assistant.update_knowledge_base(["course_data/"])
    # 提问示例
    response = assistant.ask("软件工程的定义是什么？")
    print("回答:", response)
    response = assistant.ask("什么是Multi-Head Attention？")
    print("回答:", response)
    response = assistant.ask("作业1的智能仓储机器人系统状态图如何构建？")
    print("回答:", response)
    response = assistant.ask("请详细的介绍Waterfall Model模型。")
    print("回答:", response)
    response = assistant.ask("练习.json中的第3题答案是什么？为什么?")
    print("回答:", response)
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
