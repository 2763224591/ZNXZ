from langchain_community.graphs.graph_document import GraphDocument, Node, Relationship

# ================================
# 2. 图转换器类
# ================================
class GraphTransformer:
    """图转换器"""
    def __init__(self,llm_api):
        self.llm_api=llm_api
    def convert_to_graph_documents(self, documents):
        """转换文档为图文档格式"""
        graph_documents = []
        print(f"开始转换 {len(documents)} 个文档为知识图谱...")

        for i, doc in enumerate(documents):
            try:
                print(f"正在处理第{i}个...")
                # 使用LLM提取结构化信息
                entities, relationships = self._extract_graph_data(doc, self.llm_api)

                # 创建节点
                nodes = [Node(id=entity["name"], type=entity["type"]) for entity in entities]

                # 创建关系
                relations = []
                for rel in relationships:
                    source_node = Node(id=rel["source"], type="Entity")
                    target_node = Node(id=rel["target"], type="Entity")
                    relations.append(Relationship(
                        source=source_node,
                        target=target_node,
                        type=rel["type"]
                    ))

                # 创建图文档
                graph_doc = GraphDocument(
                    nodes=nodes,
                    relationships=relations,
                    source=doc
                )
                graph_documents.append(graph_doc)

            except Exception as e:
                print(f"处理第{i + 1}个文档时出错: {e}")
                # 创建空的图文档作为回退
                graph_doc = GraphDocument(nodes=[], relationships=[], source=doc)
                graph_documents.append(graph_doc)

        print(f"转换完成，共处理 {len(graph_documents)} 个文档")
        return graph_documents

    def _extract_graph_data(self, doc, llm):
        """使用LLM提取实体和关系"""
        prompt = f"""请从以下软件工程文档中提取实体和关系，以JSON格式返回：
文档元数据：
{doc.metadata}

文档内容：
{doc.page_content}

请返回JSON格式：
{{
    "entities": [
        {{"name": "实体名称", "type": "实体类型"}},
        ...
    ],
    "relationships": [
        {{"source": "源实体", "target": "目标实体", "type": "关系类型"}},
        ...
    ]
}}

实体类型为任何与软件工程以及课程学习相关的类型，包括：概念、方法、技术、工具、过程、阶段、角色、文档、标准、模式、原则等；
关系类型为任何与软件工程以及课程学习相关的类型，包括：包含、依赖、实现、使用、产生、遵循、属于、关联、继承、组成、应用等。
注意：
对于题目（来源于json文件），
严格按照以下格式进行实体类型和关系类型提取：
{"题目库","题目编号","题目ID","题目类型","难度等级","题目内容","选项","标准答案","答案解释"}，特别的，判断题没有选项，只有真假。
对于图形（来源于xml），需要记录阶段，阶段之间的转化
"""

        try:
            response = llm.znxz(prompt)
            # 解析JSON响应
            import re
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                import json
                data = json.loads(json_match.group())
                return data.get('entities', []), data.get('relationships', [])
        except Exception as e:
            print(f"解析LLM响应失败: {e}")

        return [], []

    def _fallback_conversion(self, documents):
        """回退转换方法"""
        graph_documents = []
        for doc in documents:
            graph_doc = SimpleGraphDocument(
                source_document=doc,
                entities=[],
                relationships=[]
            )
            graph_documents.append(graph_doc)
        return graph_documents

class SimpleGraphDocument:
    """简化的图文档类"""

    def __init__(self, source_document, entities, relationships):
        self.source = source_document
        self.entities = entities
        self.relationships = relationships
        self.page_content = source_document.page_content
        self.metadata = source_document.metadata

